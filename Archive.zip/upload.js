
/*const {verifyAuth } = require('../middleware/auth/verifyAuth')
const {Router} = require('express')
const awsRouter = Router()*/

// configure the AWS SDK
const app = express();

app.post("/upload", (req, res) => {
  
});

module.exports = awsRouter

